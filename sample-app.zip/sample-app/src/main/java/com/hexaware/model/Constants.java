package com.hexaware.model;

public class Constants {
    public static final String CORE = "CORE_DB";
    public static final String SP_PROC_NAME = "login_sp";
    public static String ams;
}
