package com.hexaware.factory;

import com.hexaware.service.PaymentProfileSvc;

public class PaymentProfileSvcFactory {
    public static final String PaymentProfileSvc = "PaymentProfileSvc";

    public static PaymentProfileSvc getService(Class<PaymentProfileSvc> paymentProfileSvcClass, String paymentProfileSvc) {
        return null;
    }
}
