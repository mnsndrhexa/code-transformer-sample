package com.hexaware.service;

public interface PaymentQuickPayPaymentRespondSvc {
    String getUserName();
}
