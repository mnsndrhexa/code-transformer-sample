package com.hexaware.factory;

import com.hexaware.service.PaymentQuickPayPaymentRespondSvc;

public class PaymentQuickPayPaymentRespondSvcFactory {
    public static PaymentQuickPayPaymentRespondSvc getService(Class<PaymentQuickPayPaymentRespondSvc> paymentQuickPayPaymentRespondSvcClass, String paymentQuickPayPaymentRespondSvc) {
        return null;
    }
}
