package com.hexaware.factory;

import com.hexaware.service.DigitalPaymentProfileSvc;

public class DigitalPaymentProfileSvcFactory {
    public static String DigitalPaymentProfileSvc = "DigitalPaymentProfileSvc";

    public static DigitalPaymentProfileSvc getService(Class<DigitalPaymentProfileSvc> digitalPaymentProfileSvcClass, String digitalPaymentProfileSvc) {
        return null;
    }
}
