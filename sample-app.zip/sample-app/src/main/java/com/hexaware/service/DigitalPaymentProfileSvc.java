package com.hexaware.service;

public interface DigitalPaymentProfileSvc {
    String getUserName();
}
