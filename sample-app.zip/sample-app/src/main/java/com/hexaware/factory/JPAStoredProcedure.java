package com.hexaware.factory;

public class JPAStoredProcedure {
}
