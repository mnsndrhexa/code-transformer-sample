package com.hexaware.service;

public interface PaymentProfileSvc {
    String getUserName();
}
