package com.hexaware.service.impl;

import com.hexaware.service.DigitalPaymentProfileSvc;

public class DigitalPaymentProfileSvcImpl implements DigitalPaymentProfileSvc {

    @Override
    public String getUserName() {
        return "";
    }
}
