package com.hexaware.service.impl;

import com.hexaware.service.PaymentQuickPayPaymentRespondSvc;

public class PaymentQuickPayPaymentRespondSvcImpl implements PaymentQuickPayPaymentRespondSvc {
    @Override
    public String getUserName() {
        return "";
    }
}
